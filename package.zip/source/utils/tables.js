let blockTableClomuns =  [
  "alias",
  "box",
  "content",
  "created",
  "fcontent",
  "hash",
  "hpath",
  "ial",
  "id",
  "length",
  "markdown",
  "memo",
  "name",
  "parent_id",
  "path",
  "root_id",
  "sort",
  "subtype",
  "tag",
  "type",
  "updated",
];
export  {
    blockTableClomuns as blockTableClomuns
}