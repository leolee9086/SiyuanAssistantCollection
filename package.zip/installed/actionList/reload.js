export default [
    {
        label:"刷新",
        hints:'刷新,reload,重新加载,重载,sx',
        hintAction:(context)=>{
            window.location.reload(true)
        }
    }
]